package main

import (
	"context"
	"crypto/subtle"
	"encoding/json"
	"log"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"
)

type Server struct {
	st       *Store
	origins  []string
	smu      sync.Mutex
	sessions map[string]*session
}

type session struct {
	UserID   int
	Username string
	Name     string
	Role     string
	Expires  time.Time
}

type ctxKey struct{}

func NewServer(st *Store, origins []string) *Server {
	var clean []string
	for _, o := range origins {
		o = strings.TrimSpace(o)
		if o != "" {
			clean = append(clean, o)
		}
	}
	if len(clean) == 0 {
		clean = []string{"*"}
	}
	return &Server{st: st, origins: clean, sessions: map[string]*session{}}
}

func (s *Server) Handler() http.Handler {
	mux := http.NewServeMux()
	s.routes(mux)
	return s.cors(s.logging(mux))
}

func (s *Server) routes(mux *http.ServeMux) {
	mux.HandleFunc("GET /{$}", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		_, _ = w.Write(indexHTML)
	})
	mux.HandleFunc("GET /api/health", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, 200, map[string]any{"status": "ok", "time": time.Now()})
	})
	mux.HandleFunc("POST /api/login", s.login)
	mux.HandleFunc("POST /api/logout", s.auth(s.logout))
	mux.HandleFunc("GET /api/me", s.auth(s.me))
	mux.HandleFunc("POST /api/password", s.auth(s.changePassword))

	mux.HandleFunc("GET /api/users", s.admin(s.listUsers))
	mux.HandleFunc("POST /api/users", s.admin(s.createUser))
	mux.HandleFunc("DELETE /api/users/{id}", s.admin(s.deleteUser))

	mux.HandleFunc("GET /api/dashboard", s.auth(s.dashboard))

	s.productRoutes(mux)
	s.stockRoutes(mux)
	s.partnerRoutes(mux, "customer", "/api/customers")
	s.partnerRoutes(mux, "supplier", "/api/suppliers")
	s.orderRoutes(mux, "purchase", "/api/purchase-orders")
	s.orderRoutes(mux, "sales", "/api/sales-orders")

	mux.HandleFunc("/api/", func(w http.ResponseWriter, r *http.Request) {
		writeErr(w, 404, "接口不存在")
	})
}

// ---------- 中间件 ----------

func (s *Server) cors(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		origin := r.Header.Get("Origin")
		allow := ""
		for _, o := range s.origins {
			if o == "*" {
				allow = "*"
				break
			}
			if origin != "" && strings.EqualFold(o, origin) {
				allow = origin
			}
		}
		if allow != "" {
			h := w.Header()
			h.Set("Access-Control-Allow-Origin", allow)
			if allow != "*" {
				h.Add("Vary", "Origin")
			}
			h.Set("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
			h.Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
			h.Set("Access-Control-Max-Age", "86400")
		}
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		next.ServeHTTP(w, r)
	})
}

type statusRecorder struct {
	http.ResponseWriter
	code int
}

func (r *statusRecorder) WriteHeader(c int) { r.code = c; r.ResponseWriter.WriteHeader(c) }

func (s *Server) logging(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		t := time.Now()
		rec := &statusRecorder{ResponseWriter: w, code: 200}
		next.ServeHTTP(rec, r)
		log.Printf("%s %s %d %s", r.Method, r.URL.Path, rec.code, time.Since(t).Round(time.Microsecond))
	})
}

func (s *Server) auth(h http.HandlerFunc) http.HandlerFunc  { return s.guard(false, h) }
func (s *Server) admin(h http.HandlerFunc) http.HandlerFunc { return s.guard(true, h) }

func (s *Server) guard(adminOnly bool, h http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		tok, _ := strings.CutPrefix(r.Header.Get("Authorization"), "Bearer ")
		if tok == "" {
			writeErr(w, 401, "未登录")
			return
		}
		s.smu.Lock()
		ss := s.sessions[tok]
		if ss != nil && time.Now().After(ss.Expires) {
			delete(s.sessions, tok)
			ss = nil
		}
		s.smu.Unlock()
		if ss == nil {
			writeErr(w, 401, "登录已过期，请重新登录")
			return
		}
		if adminOnly && ss.Role != "admin" {
			writeErr(w, 403, "需要管理员权限")
			return
		}
		h(w, r.WithContext(context.WithValue(r.Context(), ctxKey{}, ss)))
	}
}

func cur(r *http.Request) *session { return r.Context().Value(ctxKey{}).(*session) }

// ---------- 工具函数 ----------

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func writeErr(w http.ResponseWriter, code int, msg string) {
	writeJSON(w, code, map[string]string{"error": msg})
}

func decode(w http.ResponseWriter, r *http.Request, v any) bool {
	r.Body = http.MaxBytesReader(w, r.Body, 1<<20)
	if err := json.NewDecoder(r.Body).Decode(v); err != nil {
		writeErr(w, 400, "请求体不是有效的 JSON")
		return false
	}
	return true
}

func pathID(w http.ResponseWriter, r *http.Request) (int, bool) {
	id, err := strconv.Atoi(r.PathValue("id"))
	if err != nil || id <= 0 {
		writeErr(w, 400, "无效的 ID")
		return 0, false
	}
	return id, true
}

func (s *Server) commit(w http.ResponseWriter) bool {
	if err := s.st.save(); err != nil {
		log.Printf("save error: %v", err)
		writeErr(w, 500, "数据保存失败: "+err.Error())
		return false
	}
	return true
}

func paginate[T any](items []T, r *http.Request) map[string]any {
	p, _ := strconv.Atoi(r.URL.Query().Get("page"))
	sz, _ := strconv.Atoi(r.URL.Query().Get("size"))
	if p < 1 {
		p = 1
	}
	if sz < 1 || sz > 200 {
		sz = 20
	}
	total := len(items)
	start := (p - 1) * sz
	if start > total {
		start = total
	}
	end := min(start+sz, total)
	return map[string]any{"items": append([]T{}, items[start:end]...), "total": total, "page": p, "size": sz}
}

func contains(s, sub string) bool {
	return strings.Contains(strings.ToLower(s), strings.ToLower(sub))
}

// ---------- 认证 / 用户 ----------

func userView(u *User) map[string]any {
	return map[string]any{"id": u.ID, "username": u.Username, "name": u.Name, "role": u.Role, "created_at": u.CreatedAt}
}

func (s *Server) login(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}
	if !decode(w, r, &in) {
		return
	}
	s.st.mu.RLock()
	u := s.st.userByName(strings.TrimSpace(in.Username))
	var ok bool
	var ss *session
	if u != nil {
		ok = subtle.ConstantTimeCompare([]byte(u.Hash), []byte(hashPwd(u.Salt, in.Password))) == 1
		ss = &session{UserID: u.ID, Username: u.Username, Name: u.Name, Role: u.Role, Expires: time.Now().Add(24 * time.Hour)}
	}
	s.st.mu.RUnlock()
	if !ok {
		writeErr(w, 401, "用户名或密码错误")
		return
	}
	tok := randHex(24)
	s.smu.Lock()
	s.sessions[tok] = ss
	s.smu.Unlock()
	writeJSON(w, 200, map[string]any{"token": tok, "user": map[string]any{"id": ss.UserID, "username": ss.Username, "name": ss.Name, "role": ss.Role}})
}

func (s *Server) logout(w http.ResponseWriter, r *http.Request) {
	tok, _ := strings.CutPrefix(r.Header.Get("Authorization"), "Bearer ")
	s.smu.Lock()
	delete(s.sessions, tok)
	s.smu.Unlock()
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (s *Server) me(w http.ResponseWriter, r *http.Request) {
	ss := cur(r)
	writeJSON(w, 200, map[string]any{"id": ss.UserID, "username": ss.Username, "name": ss.Name, "role": ss.Role})
}

func (s *Server) changePassword(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Old string `json:"old"`
		New string `json:"new"`
	}
	if !decode(w, r, &in) {
		return
	}
	if len(in.New) < 6 {
		writeErr(w, 422, "新密码至少 6 位")
		return
	}
	s.st.mu.Lock()
	defer s.st.mu.Unlock()
	u := s.st.userByID(cur(r).UserID)
	if u == nil || subtle.ConstantTimeCompare([]byte(u.Hash), []byte(hashPwd(u.Salt, in.Old))) != 1 {
		writeErr(w, 403, "原密码错误")
		return
	}
	u.Salt = randHex(8)
	u.Hash = hashPwd(u.Salt, in.New)
	if s.commit(w) {
		writeJSON(w, 200, map[string]bool{"ok": true})
	}
}

func (s *Server) listUsers(w http.ResponseWriter, r *http.Request) {
	s.st.mu.RLock()
	out := []map[string]any{}
	for _, u := range s.st.db.Users {
		out = append(out, userView(u))
	}
	s.st.mu.RUnlock()
	writeJSON(w, 200, map[string]any{"items": out, "total": len(out)})
}

func (s *Server) createUser(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Username string `json:"username"`
		Password string `json:"password"`
		Name     string `json:"name"`
		Role     string `json:"role"`
	}
	if !decode(w, r, &in) {
		return
	}
	in.Username = strings.TrimSpace(in.Username)
	if in.Username == "" || len(in.Password) < 6 {
		writeErr(w, 422, "用户名不能为空，密码至少 6 位")
		return
	}
	if in.Role != "admin" && in.Role != "staff" {
		in.Role = "staff"
	}
	if in.Name == "" {
		in.Name = in.Username
	}
	s.st.mu.Lock()
	defer s.st.mu.Unlock()
	if s.st.userByName(in.Username) != nil {
		writeErr(w, 409, "用户名已存在")
		return
	}
	u := s.st.addUser(in.Username, in.Password, in.Name, in.Role)
	if s.commit(w) {
		writeJSON(w, 201, userView(u))
	}
}

func (s *Server) deleteUser(w http.ResponseWriter, r *http.Request) {
	id, ok := pathID(w, r)
	if !ok {
		return
	}
	if id == cur(r).UserID {
		writeErr(w, 409, "不能删除当前登录用户")
		return
	}
	s.st.mu.Lock()
	defer s.st.mu.Unlock()
	for i, u := range s.st.db.Users {
		if u.ID == id {
			s.st.db.Users = append(s.st.db.Users[:i], s.st.db.Users[i+1:]...)
			s.smu.Lock()
			for t, ss := range s.sessions {
				if ss.UserID == id {
					delete(s.sessions, t)
				}
			}
			s.smu.Unlock()
			if s.commit(w) {
				writeJSON(w, 200, map[string]bool{"ok": true})
			}
			return
		}
	}
	writeErr(w, 404, "用户不存在")
}
