package main

import "time"

// User 系统用户。Salt/Hash 仅用于持久化，对外输出请使用 userView。
type User struct {
	ID        int       `json:"id"`
	Username  string    `json:"username"`
	Name      string    `json:"name"`
	Role      string    `json:"role"` // admin | staff
	Salt      string    `json:"salt"`
	Hash      string    `json:"hash"`
	CreatedAt time.Time `json:"created_at"`
}

// Product 商品（库存由库存流水维护，不能直接通过商品接口修改）。
type Product struct {
	ID        int       `json:"id"`
	SKU       string    `json:"sku"`
	Name      string    `json:"name"`
	Category  string    `json:"category"`
	Unit      string    `json:"unit"`
	Price     float64   `json:"price"` // 销售价
	Cost      float64   `json:"cost"`  // 成本价（采购完成时自动更新为最近进价）
	Stock     float64   `json:"stock"`
	MinStock  float64   `json:"min_stock"` // 安全库存，<= 该值视为低库存
	Enabled   bool      `json:"enabled"`
	CreatedAt time.Time `json:"created_at"`
}

// Partner 往来单位：客户(customer) / 供应商(supplier)。
type Partner struct {
	ID        int       `json:"id"`
	Type      string    `json:"type"`
	Name      string    `json:"name"`
	Contact   string    `json:"contact"`
	Phone     string    `json:"phone"`
	Email     string    `json:"email"`
	Address   string    `json:"address"`
	Remark    string    `json:"remark"`
	CreatedAt time.Time `json:"created_at"`
}

type OrderItem struct {
	ProductID   int     `json:"product_id"`
	ProductName string  `json:"product_name"`
	SKU         string  `json:"sku"`
	Unit        string  `json:"unit"`
	Qty         float64 `json:"qty"`
	Price       float64 `json:"price"`
	Amount      float64 `json:"amount"`
}

// Order 采购单(purchase) / 销售单(sales)。
// 状态流转：draft -> confirmed -> completed；draft/confirmed 可 cancelled。
// completed 时：采购单入库、销售单出库。
type Order struct {
	ID          int         `json:"id"`
	No          string      `json:"no"`
	Type        string      `json:"type"`
	PartnerID   int         `json:"partner_id"`
	PartnerName string      `json:"partner_name"`
	Items       []OrderItem `json:"items"`
	Total       float64     `json:"total"`
	Status      string      `json:"status"`
	Remark      string      `json:"remark"`
	CreatedBy   string      `json:"created_by"`
	CreatedAt   time.Time   `json:"created_at"`
	UpdatedAt   time.Time   `json:"updated_at"`
	CompletedAt *time.Time  `json:"completed_at,omitempty"`
}

// StockMove 库存流水。Qty 为带符号变动量。
type StockMove struct {
	ID          int       `json:"id"`
	ProductID   int       `json:"product_id"`
	ProductName string    `json:"product_name"`
	Type        string    `json:"type"` // in | out | adjust
	Qty         float64   `json:"qty"`
	Balance     float64   `json:"balance"`
	Ref         string    `json:"ref"`
	Remark      string    `json:"remark"`
	CreatedAt   time.Time `json:"created_at"`
}
