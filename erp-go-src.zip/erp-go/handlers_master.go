package main

import (
	"net/http"
	"sort"
	"strings"
	"time"
)

// ---------- 商品 ----------

type productIn struct {
	SKU      string  `json:"sku"`
	Name     string  `json:"name"`
	Category string  `json:"category"`
	Unit     string  `json:"unit"`
	Price    float64 `json:"price"`
	Cost     float64 `json:"cost"`
	Stock    float64 `json:"stock"` // 仅创建时有效，作为初始库存
	MinStock float64 `json:"min_stock"`
	Enabled  *bool   `json:"enabled"`
}

func (in *productIn) validate() string {
	in.SKU, in.Name = strings.TrimSpace(in.SKU), strings.TrimSpace(in.Name)
	switch {
	case in.SKU == "":
		return "商品编码不能为空"
	case in.Name == "":
		return "商品名称不能为空"
	case in.Price < 0 || in.Cost < 0 || in.Stock < 0 || in.MinStock < 0:
		return "价格、成本、库存、安全库存不能为负数"
	}
	if strings.TrimSpace(in.Unit) == "" {
		in.Unit = "件"
	}
	return ""
}

func (s *Server) productRoutes(mux *http.ServeMux) {
	mux.HandleFunc("GET /api/products", s.auth(s.listProducts))
	mux.HandleFunc("POST /api/products", s.auth(s.createProduct))
	mux.HandleFunc("GET /api/products/{id}", s.auth(s.getProduct))
	mux.HandleFunc("PUT /api/products/{id}", s.auth(s.updateProduct))
	mux.HandleFunc("DELETE /api/products/{id}", s.auth(s.deleteProduct))
}

func (s *Server) listProducts(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	kw, cat, low := q.Get("q"), q.Get("category"), q.Get("low") == "1"
	s.st.mu.RLock()
	out := []Product{}
	for _, p := range s.st.db.Products {
		if kw != "" && !contains(p.Name, kw) && !contains(p.SKU, kw) {
			continue
		}
		if cat != "" && p.Category != cat {
			continue
		}
		if low && p.Stock > p.MinStock {
			continue
		}
		out = append(out, *p)
	}
	s.st.mu.RUnlock()
	sort.Slice(out, func(i, j int) bool { return out[i].ID > out[j].ID })
	writeJSON(w, 200, paginate(out, r))
}

func (s *Server) getProduct(w http.ResponseWriter, r *http.Request) {
	id, ok := pathID(w, r)
	if !ok {
		return
	}
	s.st.mu.RLock()
	defer s.st.mu.RUnlock()
	if p := s.st.product(id); p != nil {
		writeJSON(w, 200, *p)
		return
	}
	writeErr(w, 404, "商品不存在")
}

func (s *Server) skuTaken(sku string, exceptID int) bool {
	for _, p := range s.st.db.Products {
		if p.ID != exceptID && strings.EqualFold(p.SKU, sku) {
			return true
		}
	}
	return false
}

func (s *Server) createProduct(w http.ResponseWriter, r *http.Request) {
	var in productIn
	if !decode(w, r, &in) {
		return
	}
	if msg := in.validate(); msg != "" {
		writeErr(w, 422, msg)
		return
	}
	s.st.mu.Lock()
	defer s.st.mu.Unlock()
	if s.skuTaken(in.SKU, 0) {
		writeErr(w, 409, "商品编码已存在")
		return
	}
	p := &Product{ID: s.st.nextID("product"), SKU: in.SKU, Name: in.Name, Category: in.Category, Unit: in.Unit,
		Price: round2(in.Price), Cost: round2(in.Cost), MinStock: in.MinStock, Enabled: in.Enabled == nil || *in.Enabled, CreatedAt: time.Now()}
	s.st.db.Products = append(s.st.db.Products, p)
	if in.Stock > 0 {
		s.st.move(p, in.Stock, "in", "初始库存", "新建商品")
	}
	if s.commit(w) {
		writeJSON(w, 201, *p)
	}
}

func (s *Server) updateProduct(w http.ResponseWriter, r *http.Request) {
	id, ok := pathID(w, r)
	if !ok {
		return
	}
	var in productIn
	if !decode(w, r, &in) {
		return
	}
	if msg := in.validate(); msg != "" {
		writeErr(w, 422, msg)
		return
	}
	s.st.mu.Lock()
	defer s.st.mu.Unlock()
	p := s.st.product(id)
	if p == nil {
		writeErr(w, 404, "商品不存在")
		return
	}
	if s.skuTaken(in.SKU, id) {
		writeErr(w, 409, "商品编码已存在")
		return
	}
	p.SKU, p.Name, p.Category, p.Unit = in.SKU, in.Name, in.Category, in.Unit
	p.Price, p.Cost, p.MinStock = round2(in.Price), round2(in.Cost), in.MinStock
	if in.Enabled != nil {
		p.Enabled = *in.Enabled
	}
	if s.commit(w) {
		writeJSON(w, 200, *p)
	}
}

func (s *Server) deleteProduct(w http.ResponseWriter, r *http.Request) {
	id, ok := pathID(w, r)
	if !ok {
		return
	}
	s.st.mu.Lock()
	defer s.st.mu.Unlock()
	for _, o := range s.st.db.Orders {
		for _, it := range o.Items {
			if it.ProductID == id {
				writeErr(w, 409, "该商品已被订单引用，无法删除，可改为停用")
				return
			}
		}
	}
	for i, p := range s.st.db.Products {
		if p.ID == id {
			s.st.db.Products = append(s.st.db.Products[:i], s.st.db.Products[i+1:]...)
			if s.commit(w) {
				writeJSON(w, 200, map[string]bool{"ok": true})
			}
			return
		}
	}
	writeErr(w, 404, "商品不存在")
}

// ---------- 库存 ----------

func (s *Server) stockRoutes(mux *http.ServeMux) {
	mux.HandleFunc("GET /api/stock/moves", s.auth(s.listMoves))
	mux.HandleFunc("POST /api/stock/adjust", s.auth(s.adjustStock))
}

func (s *Server) listMoves(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	typ, pid := q.Get("type"), q.Get("product_id")
	s.st.mu.RLock()
	out := []StockMove{}
	for _, m := range s.st.db.Moves {
		if typ != "" && m.Type != typ {
			continue
		}
		if pid != "" && pid != itoa(m.ProductID) {
			continue
		}
		out = append(out, *m)
	}
	s.st.mu.RUnlock()
	sort.Slice(out, func(i, j int) bool { return out[i].ID > out[j].ID })
	writeJSON(w, 200, paginate(out, r))
}

// adjustStock 盘点/手工调整：delta 为带符号变动量，调整后库存不得为负。
func (s *Server) adjustStock(w http.ResponseWriter, r *http.Request) {
	var in struct {
		ProductID int     `json:"product_id"`
		Delta     float64 `json:"delta"`
		Remark    string  `json:"remark"`
	}
	if !decode(w, r, &in) {
		return
	}
	if in.Delta == 0 {
		writeErr(w, 422, "调整数量不能为 0")
		return
	}
	s.st.mu.Lock()
	defer s.st.mu.Unlock()
	p := s.st.product(in.ProductID)
	if p == nil {
		writeErr(w, 404, "商品不存在")
		return
	}
	if p.Stock+in.Delta < 0 {
		writeErr(w, 409, "调整后库存不能为负数")
		return
	}
	s.st.move(p, in.Delta, "adjust", "手工调整", in.Remark)
	if s.commit(w) {
		writeJSON(w, 200, *p)
	}
}

// ---------- 客户 / 供应商 ----------

func (s *Server) partnerRoutes(mux *http.ServeMux, kind, base string) {
	mux.HandleFunc("GET "+base, s.auth(s.listPartners(kind)))
	mux.HandleFunc("POST "+base, s.auth(s.savePartner(kind, false)))
	mux.HandleFunc("GET "+base+"/{id}", s.auth(s.getPartner(kind)))
	mux.HandleFunc("PUT "+base+"/{id}", s.auth(s.savePartner(kind, true)))
	mux.HandleFunc("DELETE "+base+"/{id}", s.auth(s.deletePartner(kind)))
}

func (s *Server) listPartners(kind string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		kw := r.URL.Query().Get("q")
		s.st.mu.RLock()
		out := []Partner{}
		for _, p := range s.st.db.Partners {
			if p.Type != kind {
				continue
			}
			if kw != "" && !contains(p.Name, kw) && !contains(p.Contact, kw) && !contains(p.Phone, kw) {
				continue
			}
			out = append(out, *p)
		}
		s.st.mu.RUnlock()
		sort.Slice(out, func(i, j int) bool { return out[i].ID > out[j].ID })
		writeJSON(w, 200, paginate(out, r))
	}
}

func (s *Server) getPartner(kind string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		id, ok := pathID(w, r)
		if !ok {
			return
		}
		s.st.mu.RLock()
		defer s.st.mu.RUnlock()
		if p := s.st.partner(kind, id); p != nil {
			writeJSON(w, 200, *p)
			return
		}
		writeErr(w, 404, "记录不存在")
	}
}

func (s *Server) savePartner(kind string, update bool) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var in Partner
		if !decode(w, r, &in) {
			return
		}
		in.Name = strings.TrimSpace(in.Name)
		if in.Name == "" {
			writeErr(w, 422, "名称不能为空")
			return
		}
		s.st.mu.Lock()
		defer s.st.mu.Unlock()
		var p *Partner
		if update {
			id, ok := pathID(w, r)
			if !ok {
				return
			}
			if p = s.st.partner(kind, id); p == nil {
				writeErr(w, 404, "记录不存在")
				return
			}
		} else {
			p = &Partner{ID: s.st.nextID("partner"), Type: kind, CreatedAt: time.Now()}
		}
		p.Name, p.Contact, p.Phone, p.Email, p.Address, p.Remark = in.Name, in.Contact, in.Phone, in.Email, in.Address, in.Remark
		if !update {
			s.st.db.Partners = append(s.st.db.Partners, p)
		}
		if s.commit(w) {
			code := 200
			if !update {
				code = 201
			}
			writeJSON(w, code, *p)
		}
	}
}

func (s *Server) deletePartner(kind string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		id, ok := pathID(w, r)
		if !ok {
			return
		}
		s.st.mu.Lock()
		defer s.st.mu.Unlock()
		for _, o := range s.st.db.Orders {
			if o.PartnerID == id && o.Type == orderTypeOf(kind) {
				writeErr(w, 409, "已有订单引用该往来单位，无法删除")
				return
			}
		}
		for i, p := range s.st.db.Partners {
			if p.ID == id && p.Type == kind {
				s.st.db.Partners = append(s.st.db.Partners[:i], s.st.db.Partners[i+1:]...)
				if s.commit(w) {
					writeJSON(w, 200, map[string]bool{"ok": true})
				}
				return
			}
		}
		writeErr(w, 404, "记录不存在")
	}
}

func orderTypeOf(kind string) string {
	if kind == "customer" {
		return "sales"
	}
	return "purchase"
}
