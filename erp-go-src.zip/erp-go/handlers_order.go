package main

import (
	"errors"
	"fmt"
	"net/http"
	"sort"
	"strconv"
	"time"
)

func itoa(i int) string { return strconv.Itoa(i) }

type orderIn struct {
	PartnerID int    `json:"partner_id"`
	Remark    string `json:"remark"`
	Items     []struct {
		ProductID int     `json:"product_id"`
		Qty       float64 `json:"qty"`
		Price     float64 `json:"price"` // 为 0 时取商品默认价（销售取售价，采购取成本）
	} `json:"items"`
}

func partnerKindOf(typ string) string {
	if typ == "sales" {
		return "customer"
	}
	return "supplier"
}

// build 校验并生成订单明细（调用方需持锁）。
func (s *Server) build(typ string, in *orderIn) (*Partner, []OrderItem, float64, error) {
	pt := s.st.partner(partnerKindOf(typ), in.PartnerID)
	if pt == nil {
		if typ == "sales" {
			return nil, nil, 0, errors.New("请选择有效的客户")
		}
		return nil, nil, 0, errors.New("请选择有效的供应商")
	}
	if len(in.Items) == 0 {
		return nil, nil, 0, errors.New("至少需要一行商品明细")
	}
	var items []OrderItem
	var total float64
	for i, it := range in.Items {
		p := s.st.product(it.ProductID)
		switch {
		case p == nil:
			return nil, nil, 0, fmt.Errorf("第 %d 行：商品不存在", i+1)
		case !p.Enabled:
			return nil, nil, 0, fmt.Errorf("第 %d 行：商品【%s】已停用", i+1, p.Name)
		case it.Qty <= 0:
			return nil, nil, 0, fmt.Errorf("第 %d 行：数量必须大于 0", i+1)
		case it.Price < 0:
			return nil, nil, 0, fmt.Errorf("第 %d 行：单价不能为负数", i+1)
		}
		price := it.Price
		if price == 0 {
			price = p.Cost
			if typ == "sales" {
				price = p.Price
			}
		}
		amt := round2(it.Qty * price)
		items = append(items, OrderItem{ProductID: p.ID, ProductName: p.Name, SKU: p.SKU, Unit: p.Unit,
			Qty: it.Qty, Price: round2(price), Amount: amt})
		total += amt
	}
	return pt, items, round2(total), nil
}

func (s *Server) orderRoutes(mux *http.ServeMux, typ, base string) {
	mux.HandleFunc("GET "+base, s.auth(s.listOrders(typ)))
	mux.HandleFunc("POST "+base, s.auth(s.saveOrder(typ, false)))
	mux.HandleFunc("GET "+base+"/{id}", s.auth(s.getOrder(typ)))
	mux.HandleFunc("PUT "+base+"/{id}", s.auth(s.saveOrder(typ, true)))
	mux.HandleFunc("DELETE "+base+"/{id}", s.auth(s.deleteOrder(typ)))
	for _, act := range []string{"confirm", "complete", "cancel"} {
		mux.HandleFunc("POST "+base+"/{id}/"+act, s.auth(s.orderAction(typ, act)))
	}
}

func (s *Server) listOrders(typ string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		q := r.URL.Query()
		kw, st, pid := q.Get("q"), q.Get("status"), q.Get("partner_id")
		s.st.mu.RLock()
		out := []Order{}
		for _, o := range s.st.db.Orders {
			if o.Type != typ || (st != "" && o.Status != st) || (pid != "" && pid != itoa(o.PartnerID)) {
				continue
			}
			if kw != "" && !contains(o.No, kw) && !contains(o.PartnerName, kw) {
				continue
			}
			out = append(out, *o)
		}
		s.st.mu.RUnlock()
		sort.Slice(out, func(i, j int) bool { return out[i].ID > out[j].ID })
		writeJSON(w, 200, paginate(out, r))
	}
}

func (s *Server) getOrder(typ string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		id, ok := pathID(w, r)
		if !ok {
			return
		}
		s.st.mu.RLock()
		defer s.st.mu.RUnlock()
		if o := s.st.order(typ, id); o != nil {
			writeJSON(w, 200, *o)
			return
		}
		writeErr(w, 404, "订单不存在")
	}
}

func (s *Server) saveOrder(typ string, update bool) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var in orderIn
		if !decode(w, r, &in) {
			return
		}
		s.st.mu.Lock()
		defer s.st.mu.Unlock()
		var o *Order
		if update {
			id, ok := pathID(w, r)
			if !ok {
				return
			}
			if o = s.st.order(typ, id); o == nil {
				writeErr(w, 404, "订单不存在")
				return
			}
			if o.Status != "draft" {
				writeErr(w, 409, "只有草稿状态的订单可以修改")
				return
			}
		}
		pt, items, total, err := s.build(typ, &in)
		if err != nil {
			writeErr(w, 422, err.Error())
			return
		}
		now := time.Now()
		if !update {
			prefix := "SO"
			if typ == "purchase" {
				prefix = "PO"
			}
			o = &Order{ID: s.st.nextID("order_" + typ), Type: typ, Status: "draft", CreatedBy: cur(r).Name, CreatedAt: now}
			o.No = fmt.Sprintf("%s%s%04d", prefix, now.Format("20060102"), o.ID)
			s.st.db.Orders = append(s.st.db.Orders, o)
		}
		o.PartnerID, o.PartnerName, o.Items, o.Total, o.Remark, o.UpdatedAt = pt.ID, pt.Name, items, total, in.Remark, now
		if s.commit(w) {
			code := 200
			if !update {
				code = 201
			}
			writeJSON(w, code, *o)
		}
	}
}

func (s *Server) deleteOrder(typ string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		id, ok := pathID(w, r)
		if !ok {
			return
		}
		s.st.mu.Lock()
		defer s.st.mu.Unlock()
		for i, o := range s.st.db.Orders {
			if o.ID == id && o.Type == typ {
				if o.Status != "draft" && o.Status != "cancelled" {
					writeErr(w, 409, "只有草稿或已取消的订单可以删除")
					return
				}
				s.st.db.Orders = append(s.st.db.Orders[:i], s.st.db.Orders[i+1:]...)
				if s.commit(w) {
					writeJSON(w, 200, map[string]bool{"ok": true})
				}
				return
			}
		}
		writeErr(w, 404, "订单不存在")
	}
}

func (s *Server) orderAction(typ, action string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		id, ok := pathID(w, r)
		if !ok {
			return
		}
		s.st.mu.Lock()
		defer s.st.mu.Unlock()
		o := s.st.order(typ, id)
		if o == nil {
			writeErr(w, 404, "订单不存在")
			return
		}
		switch action {
		case "confirm":
			if o.Status != "draft" {
				writeErr(w, 409, "只有草稿订单可以确认")
				return
			}
			o.Status = "confirmed"
		case "cancel":
			if o.Status != "draft" && o.Status != "confirmed" {
				writeErr(w, 409, "当前状态不可取消")
				return
			}
			o.Status = "cancelled"
		case "complete":
			if o.Status != "confirmed" {
				writeErr(w, 409, "只有已确认的订单可以完成")
				return
			}
			if err := s.fulfil(o); err != nil {
				writeErr(w, 409, err.Error())
				return
			}
		}
		o.UpdatedAt = time.Now()
		if s.commit(w) {
			writeJSON(w, 200, *o)
		}
	}
}

// fulfil 完成订单：采购入库 / 销售出库（调用方需持写锁）。先整体校验再变更，保证原子性。
func (s *Server) fulfil(o *Order) error {
	if o.Type == "sales" {
		need := map[int]float64{}
		for _, it := range o.Items {
			need[it.ProductID] += it.Qty
		}
		for pid, n := range need {
			p := s.st.product(pid)
			if p == nil {
				return errors.New("订单中的商品已不存在")
			}
			if p.Stock < n {
				return fmt.Errorf("商品【%s】库存不足（现有 %v，需要 %v）", p.Name, p.Stock, n)
			}
		}
	}
	for _, it := range o.Items {
		p := s.st.product(it.ProductID)
		if p == nil {
			return errors.New("订单中的商品已不存在")
		}
		if o.Type == "sales" {
			s.st.move(p, -it.Qty, "out", o.No, "销售出库")
		} else {
			s.st.move(p, it.Qty, "in", o.No, "采购入库")
			p.Cost = it.Price
		}
	}
	now := time.Now()
	o.Status, o.CompletedAt = "completed", &now
	return nil
}

// ---------- 仪表盘 ----------

func (s *Server) dashboard(w http.ResponseWriter, r *http.Request) {
	s.st.mu.RLock()
	defer s.st.mu.RUnlock()
	now := time.Now()
	monthStart := time.Date(now.Year(), now.Month(), 1, 0, 0, 0, 0, now.Location())
	var stockValue float64
	low := []Product{}
	for _, p := range s.st.db.Products {
		stockValue += p.Stock * p.Cost
		if p.Enabled && p.Stock <= p.MinStock {
			low = append(low, *p)
		}
	}
	sort.Slice(low, func(i, j int) bool { return low[i].Stock < low[j].Stock })
	lowCount := len(low)
	if len(low) > 10 {
		low = low[:10]
	}
	var customers, suppliers int
	for _, p := range s.st.db.Partners {
		if p.Type == "customer" {
			customers++
		} else {
			suppliers++
		}
	}
	days := make([]string, 7)
	idx := map[string]int{}
	trendSales, trendPurchase := make([]float64, 7), make([]float64, 7)
	for i := range days {
		d := now.AddDate(0, 0, i-6)
		days[i] = d.Format("01-02")
		idx[d.Format("2006-01-02")] = i
	}
	var salesTotal, purchaseTotal, salesMonth, purchaseMonth float64
	pending := map[string]int{"sales": 0, "purchase": 0}
	for _, o := range s.st.db.Orders {
		if o.Status == "draft" || o.Status == "confirmed" {
			pending[o.Type]++
		}
		if o.Status != "completed" || o.CompletedAt == nil {
			continue
		}
		t := *o.CompletedAt
		i, inTrend := idx[t.Format("2006-01-02")]
		if o.Type == "sales" {
			salesTotal += o.Total
			if !t.Before(monthStart) {
				salesMonth += o.Total
			}
			if inTrend {
				trendSales[i] += o.Total
			}
		} else {
			purchaseTotal += o.Total
			if !t.Before(monthStart) {
				purchaseMonth += o.Total
			}
			if inTrend {
				trendPurchase[i] += o.Total
			}
		}
	}
	writeJSON(w, 200, map[string]any{
		"products": len(s.st.db.Products), "customers": customers, "suppliers": suppliers,
		"stock_value": round2(stockValue), "low_stock_count": lowCount, "low_stock": low,
		"sales_total": round2(salesTotal), "purchase_total": round2(purchaseTotal),
		"sales_month": round2(salesMonth), "purchase_month": round2(purchaseMonth),
		"pending_sales": pending["sales"], "pending_purchase": pending["purchase"],
		"trend": map[string]any{"days": days, "sales": trendSales, "purchase": trendPurchase},
	})
}
