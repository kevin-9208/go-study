# 轻量 ERP（Go 版）— 阶段一：基础版

纯 Go 标准库实现（**零第三方依赖**），单个二进制即可运行；前端为单文件 `web/index.html`（已通过 `go:embed` 内嵌到二进制中）。

## 快速开始

```bash
# 方式 1：直接运行（需要 Go 1.22+）
go run .

# 方式 2：使用预编译二进制（dist/ 目录，无需安装 Go）
./dist/erp-linux-amd64          # Linux
./dist/erp-darwin-arm64         # macOS (Apple Silicon)
dist\erp-windows-amd64.exe      # Windows
```

浏览器打开 <http://localhost:8080>，默认账号 **admin / admin123**（登录后请立即在右上角“修改密码”）。
首次启动会写入少量演示数据（3 个商品、1 个客户、1 个供应商），可随意删除/修改。

### 前后端分离 / 跨域使用
后端已启用 CORS（默认允许任意来源）。也可以把 `web/index.html` 单独放到任意静态服务器（或直接双击打开），
在登录页展开“服务地址”，填入后端地址，如 `http://localhost:8080`。

### 配置（环境变量）
| 变量 | 默认值 | 说明 |
|---|---|---|
| `ERP_ADDR` | `:8080` | 监听地址 |
| `ERP_DATA` | `data/erp.json` | 数据文件（JSON，原子写入） |
| `ERP_CORS_ORIGINS` | `*` | 允许的跨域来源，逗号分隔，如 `https://a.com,https://b.com` |

## 已实现功能（阶段一）
- **认证与用户**：登录/退出、24h 会话令牌（`Authorization: Bearer`）、修改密码、用户管理（管理员 / 普通员工）
- **商品管理**：增删改查、搜索、分类、安全库存、启用/停用、被订单引用时禁止删除
- **客户 / 供应商**：增删改查、搜索、被订单引用时禁止删除
- **采购单**：草稿 → 确认 → 入库完成（自动增加库存并更新成本价）；可编辑、取消、删除
- **销售单**：草稿 → 确认 → 出库完成（自动扣减库存，**库存不足时整单拒绝，不会部分出库**）
- **库存**：库存流水（入库/出库/调整，含结存）、手工盘点调整（调整后不得为负）
- **仪表盘**：本月/累计销售与采购额、库存总价值、待处理单据、低库存预警、近 7 日趋势
- **工程**：CORS、请求日志、优雅停机、单元/集成测试（`go test -race`）

## 业务规则
- 订单状态：`draft → confirmed → completed`；`draft/confirmed → cancelled`。只有草稿可编辑；只有草稿/已取消可删除。
- 订单明细单价填 0 时，自动取商品默认价（销售取售价，采购取成本价）。
- 商品库存**只能**通过入库/出库/调整变动（商品编辑接口不接受 `stock`），保证每次变动都有流水。

## API 一览
成功返回 JSON；失败返回 `{"error":"原因"}`，状态码：400 参数错误 / 401 未登录 / 403 无权限 / 404 不存在 / 409 状态冲突或被引用 / 422 校验失败。
列表接口统一支持 `?page=1&size=20`，返回 `{items,total,page,size}`。

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/api/login` | `{username,password}` → `{token,user}`（公开） |
| POST | `/api/logout` · GET `/api/me` · POST `/api/password` | 退出 / 当前用户 / 改密 `{old,new}` |
| GET/POST/DELETE | `/api/users` `/api/users/{id}` | 用户管理（仅管理员） |
| GET/POST | `/api/products` | 列表 `?q=&category=&low=1` / 新建（`stock` 作为初始库存） |
| GET/PUT/DELETE | `/api/products/{id}` | 详情 / 更新 / 删除 |
| GET | `/api/stock/moves` | 流水 `?product_id=&type=in\|out\|adjust` |
| POST | `/api/stock/adjust` | `{product_id,delta,remark}` 手工调整 |
| GET/POST/PUT/DELETE | `/api/customers[/{id}]` `/api/suppliers[/{id}]` | 客户 / 供应商，列表 `?q=` |
| GET/POST | `/api/purchase-orders` `/api/sales-orders` | 列表 `?q=&status=&partner_id=` / 新建 |
| GET/PUT/DELETE | `…-orders/{id}` | 详情 / 修改（仅草稿）/ 删除 |
| POST | `…-orders/{id}/confirm` `/complete` `/cancel` | 状态流转 |
| GET | `/api/dashboard` | 汇总数据 |
| GET | `/api/health` | 健康检查（公开） |

订单创建示例：
```bash
curl -X POST localhost:8080/api/sales-orders -H "Authorization: Bearer $TOKEN" \
  -d '{"partner_id":1,"remark":"","items":[{"product_id":1,"qty":2,"price":0}]}'
```

## 目录结构
```
main.go              入口、配置、优雅停机
server.go            路由、CORS/日志/鉴权中间件、认证与用户
handlers_master.go   商品、库存、客户/供应商
handlers_order.go    采购/销售订单、状态机、仪表盘
models.go store.go   数据模型、存储层（内存 + JSON 原子落盘）
web/index.html       单文件前端（内嵌进二进制）
main_test.go         集成测试
build.sh             交叉编译脚本 → dist/
```

## 后续扩展路线（建议）
- **阶段二（数据与财务）**：存储层换 SQLite/PostgreSQL（只需替换 `store.go`）；应收/应付与收付款登记；
  订单部分入库/出库、退货；多仓库；商品批次/序列号；导出 Excel/CSV；单据打印。
- **阶段三（权限与治理）**：细粒度角色权限（RBAC）、操作审计日志、JWT/刷新令牌、登录限流与锁定、
  bcrypt/argon2 密码哈希、多租户、报表与图表、消息通知。

## 已知限制（基础版有意从简）
- 数据存为单个 JSON 文件并常驻内存，适合中小规模/试用；并发安全由全局读写锁保证，不支持多实例部署。
- 会话令牌保存在内存，服务重启后需重新登录。
- 密码使用“盐 + SHA-256”，生产环境建议升级为 bcrypt/argon2（阶段三）。
- 请务必修改默认密码；公网部署请配合 HTTPS，并将 `ERP_CORS_ORIGINS` 限定为你的前端域名。
