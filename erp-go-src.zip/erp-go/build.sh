#!/bin/sh
# 交叉编译（纯标准库，CGO 关闭，各平台均可直接运行）
set -e
cd "$(dirname "$0")"
rm -rf dist && mkdir dist
for t in linux/amd64 linux/arm64 darwin/amd64 darwin/arm64 windows/amd64; do
  os=${t%/*}; arch=${t#*/}; ext=""; [ "$os" = windows ] && ext=".exe"
  CGO_ENABLED=0 GOOS=$os GOARCH=$arch go build -trimpath -ldflags "-s -w" -o "dist/erp-$os-$arch$ext" .
  echo "built dist/erp-$os-$arch$ext"
done
