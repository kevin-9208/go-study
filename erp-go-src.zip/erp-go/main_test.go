package main

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"testing"
)

type client struct {
	t     *testing.T
	url   string
	token string
}

func (c *client) do(method, path string, body any) (int, map[string]any) {
	c.t.Helper()
	var rd *bytes.Reader
	if body != nil {
		b, _ := json.Marshal(body)
		rd = bytes.NewReader(b)
	} else {
		rd = bytes.NewReader(nil)
	}
	req, _ := http.NewRequest(method, c.url+path, rd)
	req.Header.Set("Content-Type", "application/json")
	if c.token != "" {
		req.Header.Set("Authorization", "Bearer "+c.token)
	}
	res, err := http.DefaultClient.Do(req)
	if err != nil {
		c.t.Fatal(err)
	}
	defer res.Body.Close()
	var m map[string]any
	_ = json.NewDecoder(res.Body).Decode(&m)
	return res.StatusCode, m
}

func (c *client) expect(want int, method, path string, body any) map[string]any {
	c.t.Helper()
	code, m := c.do(method, path, body)
	if code != want {
		c.t.Fatalf("%s %s: 期望 %d, 实际 %d, body=%v", method, path, want, code, m)
	}
	return m
}

func setup(t *testing.T) (*client, *Store) {
	st, err := NewStore("")
	if err != nil {
		t.Fatal(err)
	}
	ts := httptest.NewServer(NewServer(st, []string{"*"}).Handler())
	t.Cleanup(ts.Close)
	c := &client{t: t, url: ts.URL}
	m := c.expect(200, "POST", "/api/login", map[string]string{"username": "admin", "password": "admin123"})
	c.token = m["token"].(string)
	return c, st
}

func f(m map[string]any, k string) float64 { return m[k].(float64) }

func TestAuthAndCORS(t *testing.T) {
	c, _ := setup(t)
	anon := &client{t: t, url: c.url}
	anon.expect(401, "GET", "/api/products", nil)
	anon.expect(401, "POST", "/api/login", map[string]string{"username": "admin", "password": "bad"})
	c.expect(200, "GET", "/api/me", nil)

	req, _ := http.NewRequest("OPTIONS", c.url+"/api/products", nil)
	req.Header.Set("Origin", "http://example.com")
	req.Header.Set("Access-Control-Request-Method", "POST")
	res, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	if res.StatusCode != 204 || res.Header.Get("Access-Control-Allow-Origin") != "*" ||
		res.Header.Get("Access-Control-Allow-Headers") == "" {
		t.Fatalf("CORS 预检失败: %d %v", res.StatusCode, res.Header)
	}
	// 普通请求同样带 CORS 头
	res, _ = http.Get(c.url + "/api/health")
	if res.Header.Get("Access-Control-Allow-Origin") != "*" {
		t.Fatal("缺少 CORS 头")
	}
	// 首页
	res, _ = http.Get(c.url + "/")
	if res.StatusCode != 200 {
		t.Fatal("首页不可访问")
	}
}

func TestCORSAllowList(t *testing.T) {
	st, _ := NewStore("")
	ts := httptest.NewServer(NewServer(st, []string{"http://a.com"}).Handler())
	defer ts.Close()
	for origin, want := range map[string]string{"http://a.com": "http://a.com", "http://b.com": ""} {
		req, _ := http.NewRequest("GET", ts.URL+"/api/health", nil)
		req.Header.Set("Origin", origin)
		res, _ := http.DefaultClient.Do(req)
		if got := res.Header.Get("Access-Control-Allow-Origin"); got != want {
			t.Fatalf("origin %s: got %q want %q", origin, got, want)
		}
	}
}

func TestProductCRUD(t *testing.T) {
	c, _ := setup(t)
	p := c.expect(201, "POST", "/api/products", map[string]any{"sku": "T-1", "name": "测试品", "price": 10, "cost": 6, "stock": 5, "min_stock": 2})
	id := int(f(p, "id"))
	if f(p, "stock") != 5 || p["unit"] != "件" {
		t.Fatalf("创建结果异常: %v", p)
	}
	c.expect(409, "POST", "/api/products", map[string]any{"sku": "t-1", "name": "重复"})
	c.expect(422, "POST", "/api/products", map[string]any{"sku": "", "name": "x"})
	c.expect(422, "POST", "/api/products", map[string]any{"sku": "N", "name": "neg", "price": -1})
	u := c.expect(200, "PUT", "/api/products/"+itoa(id), map[string]any{"sku": "T-1", "name": "改名", "price": 12, "stock": 999})
	if u["name"] != "改名" || f(u, "stock") != 5 {
		t.Fatalf("更新不应修改库存: %v", u)
	}
	l := c.expect(200, "GET", "/api/products?q=改名", nil)
	if f(l, "total") != 1 {
		t.Fatalf("搜索失败: %v", l)
	}
	c.expect(404, "GET", "/api/products/9999", nil)
	c.expect(200, "DELETE", "/api/products/"+itoa(id), nil)
	c.expect(404, "GET", "/api/products/"+itoa(id), nil)
}

func TestStockAdjust(t *testing.T) {
	c, _ := setup(t)
	p := c.expect(201, "POST", "/api/products", map[string]any{"sku": "A", "name": "A", "stock": 3})
	id := int(f(p, "id"))
	r := c.expect(200, "POST", "/api/stock/adjust", map[string]any{"product_id": id, "delta": -2, "remark": "盘亏"})
	if f(r, "stock") != 1 {
		t.Fatalf("库存应为 1: %v", r)
	}
	c.expect(409, "POST", "/api/stock/adjust", map[string]any{"product_id": id, "delta": -5})
	c.expect(422, "POST", "/api/stock/adjust", map[string]any{"product_id": id, "delta": 0})
	m := c.expect(200, "GET", "/api/stock/moves?product_id="+itoa(id), nil)
	if f(m, "total") != 2 { // 初始库存 + 调整
		t.Fatalf("流水数量异常: %v", m)
	}
}

func partnerID(c *client, path, name string) int {
	return int(f(c.expect(201, "POST", path, map[string]any{"name": name}), "id"))
}

func TestPurchaseAndSalesFlow(t *testing.T) {
	c, _ := setup(t)
	base := f(c.expect(200, "GET", "/api/dashboard", nil), "stock_value") // 含演示数据的基线
	pid := int(f(c.expect(201, "POST", "/api/products", map[string]any{"sku": "F-1", "name": "流程品", "price": 20, "cost": 10}), "id"))
	sup := partnerID(c, "/api/suppliers", "供应商X")
	cus := partnerID(c, "/api/customers", "客户Y")

	// 采购：类型校验（用客户 ID 当供应商应失败）
	c.expect(422, "POST", "/api/purchase-orders", map[string]any{"partner_id": cus + 100, "items": []map[string]any{{"product_id": pid, "qty": 1}}})
	c.expect(422, "POST", "/api/purchase-orders", map[string]any{"partner_id": sup, "items": []any{}})
	c.expect(422, "POST", "/api/purchase-orders", map[string]any{"partner_id": sup, "items": []map[string]any{{"product_id": pid, "qty": 0}}})

	po := c.expect(201, "POST", "/api/purchase-orders", map[string]any{"partner_id": sup, "items": []map[string]any{{"product_id": pid, "qty": 10, "price": 8}}})
	poID := itoa(int(f(po, "id")))
	if f(po, "total") != 80 || po["status"] != "draft" {
		t.Fatalf("采购单异常: %v", po)
	}
	c.expect(409, "POST", "/api/purchase-orders/"+poID+"/complete", nil) // 草稿不能直接完成
	c.expect(200, "PUT", "/api/purchase-orders/"+poID, map[string]any{"partner_id": sup, "items": []map[string]any{{"product_id": pid, "qty": 10, "price": 8}}})
	c.expect(200, "POST", "/api/purchase-orders/"+poID+"/confirm", nil)
	c.expect(409, "PUT", "/api/purchase-orders/"+poID, map[string]any{"partner_id": sup, "items": []map[string]any{{"product_id": pid, "qty": 1}}})
	done := c.expect(200, "POST", "/api/purchase-orders/"+poID+"/complete", nil)
	if done["status"] != "completed" || done["completed_at"] == nil {
		t.Fatalf("完成状态异常: %v", done)
	}
	p := c.expect(200, "GET", "/api/products/"+itoa(pid), nil)
	if f(p, "stock") != 10 || f(p, "cost") != 8 {
		t.Fatalf("入库后库存/成本异常: %v", p)
	}
	c.expect(409, "POST", "/api/purchase-orders/"+poID+"/complete", nil) // 不可重复入库
	c.expect(409, "DELETE", "/api/purchase-orders/"+poID, nil)

	// 销售：库存不足
	big := c.expect(201, "POST", "/api/sales-orders", map[string]any{"partner_id": cus, "items": []map[string]any{{"product_id": pid, "qty": 6}, {"product_id": pid, "qty": 6}}})
	bigID := itoa(int(f(big, "id")))
	c.expect(200, "POST", "/api/sales-orders/"+bigID+"/confirm", nil)
	c.expect(409, "POST", "/api/sales-orders/"+bigID+"/complete", nil) // 合计 12 > 10
	p = c.expect(200, "GET", "/api/products/"+itoa(pid), nil)
	if f(p, "stock") != 10 {
		t.Fatalf("失败的出库不应改变库存: %v", p)
	}
	c.expect(200, "POST", "/api/sales-orders/"+bigID+"/cancel", nil)
	c.expect(200, "DELETE", "/api/sales-orders/"+bigID, nil)

	// 销售：正常出库（单价留 0 取商品售价 20）
	so := c.expect(201, "POST", "/api/sales-orders", map[string]any{"partner_id": cus, "items": []map[string]any{{"product_id": pid, "qty": 4}}})
	soID := itoa(int(f(so, "id")))
	if f(so, "total") != 80 {
		t.Fatalf("默认售价未生效: %v", so)
	}
	c.expect(200, "POST", "/api/sales-orders/"+soID+"/confirm", nil)
	c.expect(200, "POST", "/api/sales-orders/"+soID+"/complete", nil)
	p = c.expect(200, "GET", "/api/products/"+itoa(pid), nil)
	if f(p, "stock") != 6 {
		t.Fatalf("出库后库存应为 6: %v", p)
	}
	// 引用保护
	c.expect(409, "DELETE", "/api/products/"+itoa(pid), nil)
	c.expect(409, "DELETE", "/api/customers/"+itoa(cus), nil)
	c.expect(409, "DELETE", "/api/suppliers/"+itoa(sup), nil)
	// 流水
	m := c.expect(200, "GET", "/api/stock/moves?product_id="+itoa(pid), nil)
	if f(m, "total") != 2 {
		t.Fatalf("流水应为 2 条: %v", m)
	}
	// 仪表盘
	d := c.expect(200, "GET", "/api/dashboard", nil)
	if f(d, "sales_total") != 80 || f(d, "purchase_total") != 80 || f(d, "stock_value")-base != 48 {
		t.Fatalf("仪表盘数据异常: %v", d)
	}
}

func TestUsersAndRoles(t *testing.T) {
	c, _ := setup(t)
	c.expect(201, "POST", "/api/users", map[string]any{"username": "bob", "password": "secret1", "role": "staff"})
	c.expect(409, "POST", "/api/users", map[string]any{"username": "bob", "password": "secret1"})
	c.expect(422, "POST", "/api/users", map[string]any{"username": "x", "password": "123"})
	m := c.expect(200, "POST", "/api/login", map[string]string{"username": "bob", "password": "secret1"})
	bob := &client{t: t, url: c.url, token: m["token"].(string)}
	bob.expect(403, "GET", "/api/users", nil)
	bob.expect(200, "GET", "/api/products", nil)
	bob.expect(403, "POST", "/api/password", map[string]string{"old": "wrong", "new": "newpass1"})
	bob.expect(200, "POST", "/api/password", map[string]string{"old": "secret1", "new": "newpass1"})
	c.expect(200, "POST", "/api/login", map[string]string{"username": "bob", "password": "newpass1"})
	c.expect(401, "POST", "/api/login", map[string]string{"username": "bob", "password": "secret1"})
	bob.expect(200, "POST", "/api/logout", nil)
	bob.expect(401, "GET", "/api/me", nil)
	c.expect(409, "DELETE", "/api/users/1", nil) // 不能删自己
}

func TestPersistence(t *testing.T) {
	path := filepath.Join(t.TempDir(), "d", "erp.json")
	st, err := NewStore(path)
	if err != nil {
		t.Fatal(err)
	}
	ts := httptest.NewServer(NewServer(st, nil).Handler())
	c := &client{t: t, url: ts.URL}
	c.token = c.expect(200, "POST", "/api/login", map[string]string{"username": "admin", "password": "admin123"})["token"].(string)
	c.expect(201, "POST", "/api/products", map[string]any{"sku": "PERSIST", "name": "持久化"})
	ts.Close()

	st2, err := NewStore(path)
	if err != nil {
		t.Fatal(err)
	}
	ts2 := httptest.NewServer(NewServer(st2, nil).Handler())
	defer ts2.Close()
	c2 := &client{t: t, url: ts2.URL}
	c2.token = c2.expect(200, "POST", "/api/login", map[string]string{"username": "admin", "password": "admin123"})["token"].(string)
	if l := c2.expect(200, "GET", "/api/products?q=PERSIST", nil); f(l, "total") != 1 {
		t.Fatalf("重启后数据丢失: %v", l)
	}
	// 重启后 ID 序列继续递增
	p := c2.expect(201, "POST", "/api/products", map[string]any{"sku": "P2", "name": "二号"})
	if f(p, "id") <= 4 {
		t.Fatalf("ID 序列未延续: %v", p)
	}
}
