package main

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"sync"
	"time"
)

type DB struct {
	Users    []*User        `json:"users"`
	Products []*Product     `json:"products"`
	Partners []*Partner     `json:"partners"`
	Orders   []*Order       `json:"orders"`
	Moves    []*StockMove   `json:"moves"`
	Seq      map[string]int `json:"seq"`
}

// Store 内存数据 + JSON 文件持久化（原子写入）。path 为空时仅内存（测试用）。
// 阶段二可替换为 SQLite/PostgreSQL，handlers 只通过 Store 的方法访问数据。
type Store struct {
	mu   sync.RWMutex
	path string
	db   DB
}

func NewStore(path string) (*Store, error) {
	s := &Store{path: path, db: DB{Seq: map[string]int{}}}
	fresh := true
	if path != "" {
		if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
			return nil, err
		}
		b, err := os.ReadFile(path)
		switch {
		case err == nil:
			fresh = false
			if err := json.Unmarshal(b, &s.db); err != nil {
				return nil, fmt.Errorf("数据文件损坏 %s: %w", path, err)
			}
		case !os.IsNotExist(err):
			return nil, err
		}
	}
	if s.db.Seq == nil {
		s.db.Seq = map[string]int{}
	}
	if len(s.db.Users) == 0 {
		s.addUser("admin", "admin123", "系统管理员", "admin")
	}
	if fresh {
		s.seedDemo()
	}
	return s, s.save()
}

func (s *Store) nextID(kind string) int { s.db.Seq[kind]++; return s.db.Seq[kind] }

func (s *Store) save() error {
	if s.path == "" {
		return nil
	}
	b, err := json.MarshalIndent(&s.db, "", "  ")
	if err != nil {
		return err
	}
	tmp := s.path + ".tmp"
	if err := os.WriteFile(tmp, b, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, s.path)
}

func randHex(n int) string {
	b := make([]byte, n)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

func hashPwd(salt, pwd string) string {
	h := sha256.Sum256([]byte(salt + ":" + pwd))
	return hex.EncodeToString(h[:])
}

func (s *Store) addUser(username, pwd, name, role string) *User {
	salt := randHex(8)
	u := &User{ID: s.nextID("user"), Username: username, Name: name, Role: role,
		Salt: salt, Hash: hashPwd(salt, pwd), CreatedAt: time.Now()}
	s.db.Users = append(s.db.Users, u)
	return u
}

func round2(x float64) float64 { return math.Round(x*100) / 100 }
func round3(x float64) float64 { return math.Round(x*1000) / 1000 }

// ---- 查找（调用方需持锁） ----

func (s *Store) userByName(name string) *User {
	for _, u := range s.db.Users {
		if u.Username == name {
			return u
		}
	}
	return nil
}
func (s *Store) userByID(id int) *User {
	for _, u := range s.db.Users {
		if u.ID == id {
			return u
		}
	}
	return nil
}
func (s *Store) product(id int) *Product {
	for _, p := range s.db.Products {
		if p.ID == id {
			return p
		}
	}
	return nil
}
func (s *Store) partner(kind string, id int) *Partner {
	for _, p := range s.db.Partners {
		if p.ID == id && p.Type == kind {
			return p
		}
	}
	return nil
}
func (s *Store) order(typ string, id int) *Order {
	for _, o := range s.db.Orders {
		if o.ID == id && o.Type == typ {
			return o
		}
	}
	return nil
}

// move 变更库存并记录流水（调用方需持写锁）。
func (s *Store) move(p *Product, delta float64, typ, ref, remark string) {
	p.Stock = round3(p.Stock + delta)
	s.db.Moves = append(s.db.Moves, &StockMove{
		ID: s.nextID("move"), ProductID: p.ID, ProductName: p.Name, Type: typ,
		Qty: round3(delta), Balance: p.Stock, Ref: ref, Remark: remark, CreatedAt: time.Now(),
	})
}

func (s *Store) seedDemo() {
	now := time.Now()
	for _, p := range []Product{
		{SKU: "P-1001", Name: "无线鼠标", Category: "外设", Unit: "个", Price: 79, Cost: 45, MinStock: 10},
		{SKU: "P-1002", Name: "机械键盘", Category: "外设", Unit: "个", Price: 299, Cost: 180, MinStock: 5},
		{SKU: "P-1003", Name: "27寸显示器", Category: "显示", Unit: "台", Price: 1299, Cost: 950, MinStock: 3},
	} {
		p := p
		p.ID, p.Enabled, p.CreatedAt = s.nextID("product"), true, now
		s.db.Products = append(s.db.Products, &p)
		s.move(&p, 20, "in", "初始库存", "演示数据")
	}
	s.db.Partners = append(s.db.Partners,
		&Partner{ID: s.nextID("partner"), Type: "customer", Name: "示例客户有限公司", Contact: "张三", Phone: "13800000001", CreatedAt: now},
		&Partner{ID: s.nextID("partner"), Type: "supplier", Name: "示例供应商有限公司", Contact: "李四", Phone: "13800000002", CreatedAt: now},
	)
}
