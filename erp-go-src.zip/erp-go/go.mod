module erp

go 1.22
